<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
if($_POST) {

		require_once __DIR__ . '/phpmailer/src/Exception.php';
		require_once __DIR__ . '/phpmailer/src/PHPMailer.php';
		require_once __DIR__ . '/phpmailer/src/SMTP.php';

		// passing true in constructor enables exceptions in PHPMailer
		$mail = new PHPMailer(true);

		// Server settings
			$mail->isSMTP(true);
			$mail->Host = 'smtp.gmail.com';
			$mail->SMTPAuth = true;
			$mail->SMTPSecure = 'tls';
			$mail->Port = 587;
			//$mail->SMTPDebug = 2; // for detailed debug output
			$mail->SMTPOptions = array(
							'ssl' => array(
								'verify_peer' => false,
								'verify_peer_name' => false,
								'allow_self_signed' => true
							)
						);
			$mail->Username = 'example@gmail.com'; // YOUR gmail email
			$mail->Password = 'password'; // YOUR gmail password

			// Sender and recipient settings
			$mail->setFrom($_POST["email"], $_POST["name"]);
			$mail->addAddress('example@gmail.com', 'User Name');
			$mail->addReplyTo($_POST["email"], $_POST["name"]); // to set the reply to

			// Setting the email content
			$mail->IsHTML(true);
			$mail->Subject = $_POST["subject"];
			$mail->Body = $_POST["message"];
			$mail->AltBody = 'Plain text message body for non-HTML email client. Gmail SMTP email body.';

			if($mail->Send())								//Send an Email. Return true on success or false on error
			{
				$output = json_encode(array('success' => true));
				die($output);
			}
			else
			{
				$output = json_encode(array('success' => false));
				die($output);
			}

}