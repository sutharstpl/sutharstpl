$(document).ready(function() {

  var form = $('#form'),
      email = $('#email'),
      name = $('#name'),
      subject = $('#subject'),
      message = $('#message'),
      info = $('#info'),
      submit = $("#submit");
  
  form.on('input', '#email, #subject, #message', function() {
    $(this).css('border-color', '');
    info.html('').slideUp();
  });
  
  submit.on('click', function(e) {
    e.preventDefault();
      if (validate()) {
          info.html('Sending...').css('color', 'red').slideDown();
	  var msg = '<table><thead><tr><th colspan="2">Form Summary</th></tr></thead><tr><td>Name</td><td>' + $('#name').val() + '</td></tr>' +
            	    '<tr><td>Email</td><td>' + $('#email').val() + '</td></tr>' +
                    '<tr><td>Subject</td><td>' + $('#subject').val() + '</td></tr>' +
                    '<tr><td>Message</td><td>' + $('#message').val() + '</td></tr></table>'
            var varData = "name=" + $('#name').val() + "&email=" + $('#email').val() + "&subject=" + $('#subject').val() + "&message=" + msg;
          $.ajax({
              type: "POST",
              url: "mailer.php",
              data: varData,
              dataType: "json"
          }).done(function (data) {
		alert(data);
              if (data.success) {
                  email.val('');
                  name.val('');
                  subject.val('');
                  message.val('');
                  info.html('Mail sent! Thanks For Contacting..').css('color', 'green').slideDown();
              } else {
                  info.html('Could not send mail! Sorry!').css('color', 'red').slideDown();
              }
          });
      }
      else {
          info.html('Please Fill complete form...').css('color', 'red').slideDown();
      }
  });
  
  function validate() {
    var valid = true;
      var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if ($.trim(name.val()) === "") {
        name.css('border-color', 'red');
    valid = false;
    }
    if(!regex.test(email.val())) {
      email.css('border-color', 'red');
      valid = false;
    }
    if($.trim(subject.val()) === "") {
      subject.css('border-color', 'red');
      valid = false;
    }
    if($.trim(message.val()) === "") {
      message.css('border-color', 'red');
      valid = false;
    }
    
    return valid;
  }

});